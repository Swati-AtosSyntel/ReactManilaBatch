import React,{Component} from 'react';
import TableRow from './TableRow';

class Employee extends React.Component{
    constructor(){
        super();
        this.state={
            employees:[
                {empid:123,ename:"Swati"},
                {empid:124,ename:"Smith"},
                {empid:125,ename:"Ankita"},
                {empid:126,ename:"Ankit"},
                {empid:127,ename:"Mahesh"},
                {empid:128,ename:"Jana"}
            ]
        }
    }
    render(){
        return(
            <table border="1">
                <tr>
                    <th>EmployeeID</th>
                    <th>Employee Name</th>
                </tr>
                <tbody>
                {this.state.employees.map((e)=><TableRow empid={e.empid} ename={e.ename}/>)}
                </tbody>
            </table>
        )
    }
}
export default Employee;