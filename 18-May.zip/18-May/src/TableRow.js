import React,{Component} from 'react';

class TableRow extends React.Component{
    render(){
        return(
        <tr>
            <td>{this.props.empid}</td>
            
            <td>{this.props.ename}</td>
        </tr>
        )
    }
    
}
export default TableRow;