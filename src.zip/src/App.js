import logo from './logo.svg';
import './App.css';
import App1 from './App1';
import Employee from './Employee';
import App2 from './App2';

function App(props) {
  return (
    <div>
      <header>
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <h3>Welcome {props.name}, This is React JS!!!!!</h3>
        <App2/>
        <a
         
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <App1/>
        <Employee/>
       

      </header>
    </div>
  );
}
App.defaultProps={name:"React"}
export default App;
