import React,{Component} from 'react';
import TableRow from './TableRow';
class App1 extends React.Component{
    constructor(){
        super();
        this.state={EmployeeId:123,EmpName:"Swati"};
    }
    render(){
        return(
            <div>
                <ul>
                    <li>{this.state.EmployeeId}</li>
                    <li>{this.state.EmpName}</li>
                </ul>
                <hr/>
                <table border="1">
                    <tr>
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                    </tr>
                    <tbody>
                        <TableRow empid={this.state.EmployeeId} ename={this.state.EmpName}/>
                    </tbody>
                </table>

            </div>
        )
    }
}

export default App1;